from django.shortcuts import render
from requests import *

def home(request):
	if request.GET.get("btn"):
		url="https://zenquotes.io/api/random"
		res=get(url)
		data=res.json()
		msg=data[0]["q"] + "  -" + data[0]['a']
		return render(request,"home.html",{"msg":msg})
	else:
		return render(request,"home.html")
